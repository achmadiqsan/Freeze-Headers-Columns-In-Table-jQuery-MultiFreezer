# MultiFreezer
jQuery MultiFreezer - scrollable tables with freezed thead and (n) first columns

Example: https://jsfiddle.net/2oj9c5q2/21
